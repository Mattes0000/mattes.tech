import javax.swing.*;
import javax.swing.text.AbstractDocument;
import java.awt.*;
import java.util.Objects;
import java.util.Random;

public class ExecuteVirus {
    Random random;
    JLabel labelm1;
    JButton button1;
    JLabel Displayfield1;
    JLabel Displayfield2;

    ExecuteVirus(){
        for(int i=0; i<100; i++) {
            Virusframe_1();
            Virusframe_2();
            Virusframe_3();
        }
    }

    public void Virusframe_1(){

            random = new Random();
            int x = random.nextInt(800);
            int y = random.nextInt(500);
            JPanel panel = new JPanel();
            JFrame frame = new JFrame();
            frame.setSize(750, 550);//800 600
            frame.setLocation(x,y);
            frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            frame.setResizable(false);
            frame.add(panel);
            frame.requestFocus();
            frame.setTitle("Hot singles nearby!!! DONT MISS OUT");
            panel.setLayout(null);
            frame.setVisible(true);
            labelm1 = new JLabel("[Hot MILF Nearby!] HotMilf69 sent you a friend Request!!!!!");
            labelm1.setBounds(50 ,5, 700, 50);
            labelm1.setFont(new Font("sans",Font.BOLD, 24));
            panel.add(labelm1);

            try{
                ImageIcon image1 = new ImageIcon(Objects.requireNonNull(getClass().getResource("m1.png")));
                Displayfield1 = new JLabel(image1);
                Displayfield1.setBounds(10, 50,300,400);
                panel.add(Displayfield1);
            } catch (Exception e) {
                System.out.println("image cannot be found");
            }
            try{
                ImageIcon image2 = new ImageIcon(Objects.requireNonNull(getClass().getResource("m2.png")));
                Displayfield2 = new JLabel(image2);
                Displayfield2.setBounds(330, 50,300,400);
                panel.add(Displayfield2);
            } catch (Exception e) {
                System.out.println("image cannot be found");
            }

            button1 = new JButton("Accept");
            button1.setBounds(50 ,450, 200, 50);
            button1.setFont(new Font("sans",Font.BOLD, 20));
            panel.add(button1);


    }
    public void Virusframe_2(){



            random = new Random();
            int x = random.nextInt(800);
            int y = random.nextInt(500);
            JPanel panel = new JPanel();
            JFrame frame = new JFrame();
            frame.setSize(750, 300);//800 600
            frame.setLocation(x,y);
            frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            frame.setResizable(false);
            frame.add(panel);
            frame.requestFocus();
            frame.setTitle("[Millionth user of] TotallyNotaScam.org!!!");
            panel.setLayout(null);
            frame.setVisible(true);

            labelm1 = new JLabel("[Congratulations] you're the millionth user of TotallyNotaScam.org");
            labelm1.setBounds(50 ,5, 700, 50);
            labelm1.setFont(new Font("sans",Font.BOLD, 20));
            panel.add(labelm1);

            button1 = new JButton("ACCEPT PRIZE");
            button1.setBounds(150 ,50, 400, 200);
            button1.setFont(new Font("sans",Font.BOLD, 40));
            panel.add(button1);


    }
    public void Virusframe_3(){




            random = new Random();
            int x = random.nextInt(800);
            int y = random.nextInt(500);
            JPanel panel = new JPanel();
            JFrame frame = new JFrame();
            frame.setSize(625, 550);//800 600
            frame.setLocation(x,y);
            frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            frame.setResizable(false);
            frame.add(panel);
            frame.requestFocus();
            frame.setTitle("NIGERIAN PRINCES NEED YOUR HELP");
            panel.setLayout(null);
            frame.setVisible(true);
            labelm1 = new JLabel("NigerianPrince420 Neeeds Money! HELP HIM!");
            labelm1.setBounds(50 ,5, 700, 50);
            labelm1.setFont(new Font("sans",Font.BOLD, 24));
            panel.add(labelm1);

            try{
                ImageIcon image1 = new ImageIcon(Objects.requireNonNull(getClass().getResource("nigprince1.png")));
                Displayfield1 = new JLabel(image1);
                Displayfield1.setBounds(10, 50,300,400);
                panel.add(Displayfield1);
            } catch (Exception e) {
                System.out.println("image cannot be found");
            }
            try{
                ImageIcon image2 = new ImageIcon(Objects.requireNonNull(getClass().getResource("nigprince2.png")));
                Displayfield2 = new JLabel(image2);
                Displayfield2.setBounds(330, 50,300,400);
                panel.add(Displayfield2);
            } catch (Exception e) {
                System.out.println("image cannot be found");
            }

            button1 = new JButton("HELP");
            button1.setBounds(250 ,460, 150, 40);
            button1.setFont(new Font("sans",Font.BOLD, 16));
            panel.add(button1);


    }


}
