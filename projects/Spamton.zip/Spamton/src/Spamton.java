import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

public class Spamton {
    JFrame firstframe;
    JPanel firstpanel;
    JLabel Specildeal;
    JLabel Specildeal2;
    ImageIcon Image1;
    JLabel displayfield;
    JButton Accept;
    JButton Deny;
    JLabel DenyClick;
    JLabel AcceptClick;


    public Spamton(){
        System.out.println();

        Timer timer = new Timer();
        int millis = 1000;
        JPanel panel = new JPanel();
        JFrame frame = new JFrame();
        frame.setSize(700, 800);
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.add(panel);
        frame.requestFocus();
        frame.setTitle("Spamton.exe [BIG SHOT]");
        panel.setLayout(null);

        music().start();
        Specildeal = new JLabel("Hey kid, do you want to be a [Big Shot]? " +
                "\n Don't you want some [Hyperlink Blocked]?");
        Specildeal.setBounds(50 ,20, 600, 50);
        Specildeal.setFont(new Font("sans",400, 16));
        panel.add(Specildeal);

        try{
            ImageIcon image1 = new ImageIcon(getClass().getResource("spamton.png"));
            displayfield = new JLabel(image1);
            displayfield.setBounds(200, 20,300,600);
            panel.add(displayfield);
        } catch (Exception e) {
            System.out.println("image cannot be found");
        }

        Specildeal = new JLabel("Accept now and I will throw in [3 Easy payments of 9.99$!]");
        Specildeal.setBounds(150 ,550, 600, 50);
        Specildeal.setFont(new Font("sans",400, 16));
        panel.add(Specildeal);

        Accept = new JButton("Accept");
        Accept.setFont(new Font("sans", Font.BOLD, 20));
        Accept.setBounds(150,600,100,40);
        panel.add(Accept);

        AcceptClick = new JLabel("[Transmit Kromer]");
        AcceptClick.setFont(new Font("sans", Font.BOLD, 20));
        AcceptClick.setBounds(150,640,300,40);
        panel.add(AcceptClick);
        AcceptClick.setVisible(false);
        Accept.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AcceptClick.setVisible(true);
                DenyClick.setVisible(false);
                music().close();
                confirmedSound().start();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {


                        new ExecuteVirus();
                        frame.setVisible(false);
                    }
                }, millis);

            }
        });






        Deny = new JButton("Deny");
        Deny.setFont(new Font("sans", 400, 14));
        Deny.setBounds(450,600,100,40);
        panel.add(Deny);

        DenyClick = new JLabel("Wrong.");
        DenyClick.setFont(new Font("sans", Font.BOLD, 20));
        DenyClick.setBounds(470,640,100,40);
        panel.add(DenyClick);
        DenyClick.setVisible(false);
        Deny.addActionListener(e -> DenyClick.setVisible(true));



        frame.setVisible(true);
    }


    public  Clip music(){
        try {
            File file = new File("src/OST/true_theme2.wav");
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(file));

            return clip;

        } catch (Exception e) {
            System.out.println(e);
        }

        return null;
    }
    public Clip confirmedSound() {
        try {
            File file = new File("src/OST/confirmed.wav");
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(file));
            clip.loop(Clip.LOOP_CONTINUOUSLY);
            return clip;

        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }





    public static void main(String[] args){
        new Spamton();
    }

}
