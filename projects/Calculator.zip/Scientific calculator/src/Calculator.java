public class Calculator{
    int a;
    GUI gui;
    public Calculator() {
        new GUI();
    }


    public static void main(String[] args) {
        new Calculator();
    }
}
